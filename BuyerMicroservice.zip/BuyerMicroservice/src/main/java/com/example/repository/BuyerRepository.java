package com.example.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface BuyerRepository extends JpaRepository<BuyerInfo,Integer> {

}
