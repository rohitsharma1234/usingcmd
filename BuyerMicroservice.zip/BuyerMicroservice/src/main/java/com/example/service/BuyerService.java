package com.example.service;

public class BuyerService {

}
