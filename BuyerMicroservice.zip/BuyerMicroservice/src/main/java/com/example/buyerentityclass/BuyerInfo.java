package com.example.buyerentityclass;

public class BuyerInfo {

}
