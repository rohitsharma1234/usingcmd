package com.example.buyerentityclass;

import javax.annotation.Generated;

import org.springframework.boot.autoconfigure.domain.EntityScan;

@EntityScan
public class CartItem {
	@Id
	@Generated
	private Integer cartItemId;
	@OneToOne
	private Item item;
	private Integer quantity;
	@ManyToOne
	@JoinColumn(name = "buyerId")
	private BuyerInfo buyer;
	public Integer getCartItemId() {
		return cartItemId;
	}
	public void setCartItemId(Integer cartItemId) {
		this.cartItemId = cartItemId;
	}
	public Item getItem() {
		return item;
	}
	public void setItem(Item item) {
		this.item = item;
	}
	public Integer getQuantity() {
		return quantity;
	}
	@Override
	public String toString() {
		return "CartItem [cartItemId=" + cartItemId + ", quantity=" + quantity + ", buyer=" + buyer + "]";
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public BuyerInfo getBuyer() {
		return buyer;
	}
	public void setBuyer(BuyerInfo buyer) {
		this.buyer = buyer;
	}
	public CartItem(Integer cartItemId, Item item, Integer quantity, BuyerInfo buyer) {
		super();
		this.cartItemId = cartItemId;
		this.item = item;
		this.quantity = quantity;
		this.buyer = buyer;
	}
	
	
	
}
