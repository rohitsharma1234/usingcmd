package com.example.buyerentityclass;

public class TransactionHistory {

}
