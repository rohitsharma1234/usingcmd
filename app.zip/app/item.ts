export class Item{
    itemId:number;
itemName:String;
price:number;
seller:number;
stock:number;
remarks:String;
description:String;
categoryId : number;
subCategoryId : number;
}