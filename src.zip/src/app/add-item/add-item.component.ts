import { Component, OnInit } from '@angular/core';
import{SellerServiceService} from '../seller-service.service';
import { AddItem, Category, SubCategory } from '../seller';
@Component({
  selector: 'app-add-item',
  templateUrl: './add-item.component.html',
  styleUrls: ['./add-item.component.css']
})
export class AddItemComponent implements OnInit {

  constructor(private sellerService:SellerServiceService) { }
   
  addItem:AddItem=new AddItem();
  category:Category=new Category();
  subCategory:SubCategory=new SubCategory();
  //itemDetail:any;
  ngOnInit(): void {
  }
onSubmit1(){
  console.log("dkfaj")
  this.sellerService.addItemToSeller(this.addItem).subscribe(itemDetail=>this.addItem=itemDetail);
  console.log("kfjsdak")
}
}
