import { Component, OnInit } from '@angular/core';
import { SellerServiceService } from '../seller-service.service';
import {Buyer, Address} from 'cart';
@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {

  buyer:Buyer =new Buyer();
  buyerDetails:any
  constructor(private sellerService:SellerServiceService) { }

  ngOnInit(): void {
  }
onSubmit(){
  console.log("hello")
  console.log(this.buyer.buyerAddress.houseNumber);
  this.sellerService.addBuyer(this.buyer).subscribe(buyerDetails=>this.buyer=buyerDetails);
  console.log("24345")
}
}
