import { Component, OnInit } from '@angular/core';
import { SellerServiceService } from '../seller-service.service';

import {TransactionHistory} from 'cart';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {
transaction:TransactionHistory=new TransactionHistory();
  constructor(private sellerService:SellerServiceService) { }

  ngOnInit(): void {
  }
checkout(transaction:TransactionHistory){
  console.log("klfjasdlkfj")
  this.sellerService.checkout(this.transaction).subscribe(Message=>{alert("successfull");});

}
emptyCart(){
  this.sellerService.emptyCart().subscribe(Message=>{("cart empty");});
}
}
