export class Seller{
 email:String;
 username :String ;
 password :String;
 companyName: String ;
 contactNumber:number;
}
export class AddItem{
    itemName:String;
    seller: Seller=new Seller();
    categoryId:string ;
     subCategoryId:string;
     price:number;
     stock:number;
}
export class Category{
    categoryId:number;
    categoryName:String;
	 briefDetail:String;
}
export class SubCategory{
    subCategoryId:number;
    subCategoryName:String ;
    briefDetail:String;
}
export class ShowList{
    itemId:number;
    itemName:String;
    categoryId:number;
    subCategoryId:number;
    price:number;
    stock:number;
}