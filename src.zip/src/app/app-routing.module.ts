import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SearchProductComponent } from './search-product/search-product.component';
import { ViewcartComponent } from './viewcart/viewcart.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import {CheckoutComponent} from './checkout/checkout.component';
const routes: Routes = [
{path:'searchItem',component:SearchProductComponent},
{path:'viewCartComponent',component:ViewcartComponent},
{path:'onSubmit',component:SignUpComponent},
{path:'checkout',component:CheckoutComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
