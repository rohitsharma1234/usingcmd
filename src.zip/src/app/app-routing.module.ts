import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SearchProductComponent } from './search-product/search-product.component';
import { ViewcartComponent } from './viewcart/viewcart.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import {CheckoutComponent} from './checkout/checkout.component';
import {LoginComponent} from './login/login.component'
import { LogoutComponent } from './logout/logout.component';
const routes: Routes = [
{path:'searchItem',component:SearchProductComponent},
{path:'viewCartComponent',component:ViewcartComponent},
{path:'onSubmit',component:SignUpComponent},
{path:'checkout',component:CheckoutComponent},
{path:'Login',component:LoginComponent},
{path:'Logout',component:LogoutComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
