import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddSellerComponent } from './add-seller/add-seller.component';
import { AddItemComponent } from './add-item/add-item.component';
import { ProductListComponent } from './product-list/product-list.component';
import {LoginComponent} from './login/login.component';
const routes: Routes = [
  {path:'onSubmit',component:AddSellerComponent},
  {path:'onSubmit1',component:AddItemComponent},
  {path:'onSubmit2',component:ProductListComponent},
  {path:'onLogin',component:LoginComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
