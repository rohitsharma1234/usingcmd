import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SearchProductComponent } from './search-product/search-product.component';
import { ViewcartComponent } from './viewcart/viewcart.component';

const routes: Routes = [
{path:'searchItem',component:SearchProductComponent},
{path:'viewCartComponent',component:ViewcartComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
