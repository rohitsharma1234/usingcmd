import { Component, OnInit } from '@angular/core';
import { Item } from 'cart';
import { SellerServiceService } from '../seller-service.service';
@Component({
  selector: 'app-search-product',
  templateUrl: './search-product.component.html',
  styleUrls: ['./search-product.component.css']
})
export class SearchProductComponent implements OnInit {
name:String;
item:Item;
itemdata : Item[];
  constructor(private sellerservice: SellerServiceService) { }

  ngOnInit(): void {
    this.name="";
  }
  searchItem(){
    console.log("invoked searchItem()");
    this.sellerservice.getItemByName(this.name).subscribe(itemdata=>this.itemdata = itemdata);
    console.log("my name is khan")
  }
}
