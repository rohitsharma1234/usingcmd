import { Component, OnInit } from '@angular/core';
import { SellerServiceService } from '../seller-service.service';
import { ViewCart } from 'cart';

@Component({
  selector: 'app-viewcart',
  templateUrl: './viewcart.component.html',
  styleUrls: ['./viewcart.component.css']
})
export class ViewcartComponent implements OnInit {

  constructor(private cartService:SellerServiceService) { }
  viewCart : ViewCart=new ViewCart();
  view:ViewCart[];
  totalAmount:number=0;

  ngOnInit(): void {
    this.cartService.viewCart().subscribe(itemview=>this.view=itemview)
  }
increment(cartView:ViewCart){
cartView.quantity=+1;
console.log("helloooo");
this.cartService.updateCart(this.viewCart,cartView.cartItemId).subscribe(newView=>this.viewCart=newView);
console.log("hello");
}
decrement(cartView:ViewCart){
  cartView.quantity=-1;
  this.cartService.updateCart(this.viewCart,cartView.cartItemId).subscribe(newView=>this.viewCart=newView);
}
deleteCart(cartItemId:number){
  this.cartService.deleteCart(cartItemId).subscribe(()=>this.viewCartComponent());
}
viewCartComponent(){
  this.cartService.viewCart().subscribe(itemView=>this.view=itemView)
  
}

}
