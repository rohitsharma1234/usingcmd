import { Component } from '@angular/core';
import { SellerServiceService } from './seller-service.service';
import { Item } from 'cart';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'App5';
  


constructor() {
  console.log("constructor invoked");
}

}
