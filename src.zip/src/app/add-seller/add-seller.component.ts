import { Component, OnInit } from '@angular/core';
import {SellerServiceService} from '../seller-service.service';
import { Seller } from '../seller';
@Component({
  selector: 'app-add-seller',
  templateUrl: './add-seller.component.html',
  styleUrls: ['./add-seller.component.css']
})
export class AddSellerComponent implements OnInit {

  constructor(private sellerService:SellerServiceService) { }

   seller:Seller =new Seller();
   sellerDetail:any;
  ngOnInit(): void {
  }

  onSubmit(){
    console.log("hello");
     this.sellerService.addSeller(this.seller).subscribe(sellerDetail=>this.seller=sellerDetail);
  }
}
