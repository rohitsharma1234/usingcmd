import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import { Cart, ViewCart } from 'cart';
import { ThrowStmt } from '@angular/compiler';
import {Buyer}  from 'cart';
import {TransactionHistory} from 'cart';
@Injectable({
  providedIn: 'root'
})
export class SellerServiceService {
  private baseUrl='http://localhost:8081/searchItem';
  constructor(private http: HttpClient) { }
  getItemByName(name: String):Observable<any>{
  return this.http.get(`${this.baseUrl}/${name}`);
  }
  addToCart(cart:Cart): Observable<any> {
         console.log()
    return this.http.post(`http://localhost:4202/8/addToCart`,cart);

    
  }
  updateCart(cartView:ViewCart,cartItemId:number): Observable<any>{
    
 return this.http.put(`http://localhost:4202/${cartItemId}/updateCartItem`,cartView);
  }
  viewCart(): Observable<any>{
    return this.http.get(`http://localhost:4202/8/getAllCartItems`);
  }
  deleteCart(cartItemId:number): Observable<any>{
     
    return this.http.delete(`http://localhost:4202/${cartItemId}/deleteItemById`);
    
  }
  
  addBuyer(buyer:Buyer):Observable<any>{
    console.log("my name is ")
    return this.http.post(`http://localhost:4202/adduser`,buyer);
    console.log("dkfksdjfksdjfksdjf")
  }
  checkout(transaction:TransactionHistory):Observable<any>{
    return this.http.post(`http://localhost:4202/8/checkout`,transaction);
  }
}
