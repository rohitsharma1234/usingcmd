import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Seller, AddItem, ShowList } from './seller';
@Injectable({
  providedIn: 'root'
})
export class SellerServiceService {

  constructor(private http:HttpClient) { }




  addSeller(seller:Seller):Observable<any>{
    
    return this.http.post(`http://localhost:8081/addSeller`,seller);
    console.log("ajfklsad")
  }
  addItemToSeller(addItem:AddItem):Observable<any>{
    console.log("jadkfjasdkjf")
    return this.http.post('http://localhost:8081/5/additems',addItem);
  }
  showCart():Observable<any>{
    return this.http.get(`http://localhost:8081/getallItem`);
  }
}
