import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import { Cart } from 'cart';


@Injectable({
  providedIn: 'root'
})
export class SellerServiceService {
  private baseUrl='http://localhost:8081/searchItem';
  constructor(private http: HttpClient) { }
  getItemByName(name: String):Observable<any>{
  return this.http.get(`${this.baseUrl}/${name}`);
  }
  addToCart(cart: Cart): Observable<any> {
    return this.http.post('http://localhost:8081/1/addToCart',cart);
  }
  
}
