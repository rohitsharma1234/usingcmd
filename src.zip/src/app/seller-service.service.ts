import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import { Cart, ViewCart } from 'cart';
import { ThrowStmt } from '@angular/compiler';


@Injectable({
  providedIn: 'root'
})
export class SellerServiceService {
  private baseUrl='http://localhost:8081/searchItem';
  constructor(private http: HttpClient) { }
  getItemByName(name: String):Observable<any>{
  return this.http.get(`${this.baseUrl}/${name}`);
  }
  addToCart(cart: Cart): Observable<any> {
    return this.http.post(`http://localhost:4202/8/addToCart`,cart);
  }
  updateCart(cartView:ViewCart,cartItemId:number): Observable<any>{
    console.log("hiiiii12233");
 return this.http.put(`http://localhost:4202/16/updateCartItem`,cartView);
 console.log("heyyyy");
  }
  viewCart(): Observable<any>{
    return this.http.get(`http://localhost:4202/8/getAllCartItems`);
  }
  deleteCart(cartItemId:number): Observable<any>{
    return this.http.delete(`http://localhost:8081/14/deleteItemById`);
  }
  getItemList(sellerId:number):Observable<any>{
    return this.http.get(`http://localhost:8082/sellerId/getItemList`);
  }
}
