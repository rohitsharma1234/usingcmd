import { Component, OnInit } from '@angular/core';
import { ShowList } from '../seller';
import { SellerServiceService } from '../seller-service.service';
import { ThrowStmt } from '@angular/compiler';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  constructor(private sellerService:SellerServiceService) { }
    
    item:ShowList=new ShowList();
    
  ngOnInit(): void {
    this.sellerService.showCart().subscribe(listDetail=>this.item=listDetail);
  }

  //onSubmit2(){
    //this.sellerService.showCart(this.showlist).subscribe(listDetail=>this.item=listDetail);

  
}
