package com.egg.service.impl;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.egg.dao.AddressRepository;
import com.egg.dao.BuyerInfoRepository;
import com.egg.model.BuyerInfo;



@Service
public class BuyerService implements UserDetailsService{

	@Autowired
	private BuyerInfoRepository buyerRepository;
	@Autowired
	private AddressRepository addressRepository;
	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;

	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		BuyerInfo user = buyerRepository.findByUsername(username);
		if(user == null){
			throw new UsernameNotFoundException("Invalid username or password.");
		}
		return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(), getAuthority());
	}

	private List<SimpleGrantedAuthority> getAuthority() {
		return Arrays.asList(new SimpleGrantedAuthority("ROLE_ADMIN"));
	}
	public BuyerInfo addBuyer(BuyerInfo buyer) {
		addressRepository.save(buyer.getBuyerAddress());
		buyer.setPassword(bcryptEncoder.encode(buyer.getPassword()));
		return buyerRepository.save(buyer);
	}
	public BuyerInfo findOne(String username) {
		// TODO Auto-generated method stub
		return buyerRepository.findByUsername(username);
		
	}
}
