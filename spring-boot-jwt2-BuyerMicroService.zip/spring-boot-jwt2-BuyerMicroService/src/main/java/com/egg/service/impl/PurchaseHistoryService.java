package com.egg.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.egg.dao.PurchaseHistoryRepository;
import com.egg.dao.TransactionHistoryRepository;
import com.egg.model.PurchaseHistory;



@Service
public class PurchaseHistoryService {
@Autowired
public PurchaseHistoryRepository purchaseHistoryRepo;
@Autowired
public TransactionHistoryRepository transactionHistoryRepo;
 

public PurchaseHistory addPurchaseStatement(PurchaseHistory purchaseStatement) {
	return purchaseStatement;
}
	
	
}
