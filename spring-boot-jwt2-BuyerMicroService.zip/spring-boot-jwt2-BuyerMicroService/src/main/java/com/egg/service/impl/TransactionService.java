package com.egg.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.egg.dao.BuyerInfoRepository;
import com.egg.dao.TransactionHistoryRepository;
import com.egg.model.BuyerInfo;
import com.egg.model.TransactionHistory;



@Service
public class TransactionService {

	@Autowired
	private TransactionHistoryRepository transactionRepository;
	@Autowired 
	private BuyerInfoRepository buyerRepository;
	 
	public TransactionHistory trasactionStatement(TransactionHistory transactionStatement,Integer buyerId) {
	Optional<BuyerInfo>	  buyer = buyerRepository.findById(buyerId);
	 transactionStatement.setBuyer(buyer.get());
	 return transactionRepository.save(transactionStatement);
	 
		         
	}
	
}
