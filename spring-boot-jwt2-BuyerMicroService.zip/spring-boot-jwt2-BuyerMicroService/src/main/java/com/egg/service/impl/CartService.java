package com.egg.service.impl;
import java.util.List;

//import org.hibernate.cache.spi.support.AbstractReadWriteAccess.Item;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.egg.dao.AddressRepository;
import com.egg.dao.BuyerInfoRepository;
import com.egg.dao.CartRepository;
import com.egg.dao.ItemRepository;
import com.egg.dao.PurchaseHistoryRepository;
import com.egg.dao.TransactionHistoryRepository;
import com.egg.model.BuyerInfo;
import com.egg.model.CartItem;
import com.egg.model.OrderItem;
import com.egg.model.PurchaseHistory;
import com.egg.model.TransactionHistory;

import java.util.Optional;
//import com.example.repository.CartRepository;
//import com.example.repository.TransactionHistoryRepository;


@Service 
public class CartService {

	@Autowired
	private CartRepository cartRepository;
	@Autowired
	private ItemRepository itemRepository;
	@Autowired
	private BuyerInfoRepository buyerRepository;
	@Autowired
	private AddressRepository addressRepository;
	@Autowired 
	private PurchaseHistoryRepository purchaseHistoryRepository;
	@Autowired
	private TransactionHistoryRepository transactionHistoryRepository;
   public CartItem addToCartItem(CartItem cartItem,Integer buyerId) {
Optional<BuyerInfo> buyer= buyerRepository.findById(buyerId);
cartItem.setBuyer(buyer.get());
return cartRepository.save(cartItem);
	   
   }
   
   public String deleteCartItem(Integer cartItemId) {
	   cartRepository.deleteById(cartItemId);
	   return "deleted";
   }
   public String deleteAllCartItem(Integer buyerId) {
	   cartRepository.deleteByBuyerId(buyerId);
	   return "EmptyCart";
	   
   }
   public List<CartItem> getAllCartItems(Integer buyerId){
	   List<CartItem> items=cartRepository.findAllCartItem(buyerId);
	   return items;
   }
  public CartItem updateCartItems(CartItem item,Integer cartItemId) {
	 Optional<CartItem> cartItem   = cartRepository.findById(cartItemId);
	if(cartItem.isPresent()) {
		CartItem newcartitem=cartItem.get();
		newcartitem.setQuantity(item.getQuantity());
		return cartRepository.save(newcartitem);
	
	}
	return null;
  }
public void checkOut(Integer buyerId) {
	double Amount=0.00;
	TransactionHistory transactionHistory=null;
	PurchaseHistory purchaseHistory=null;
	List<CartItem> cartItem = cartRepository.findAllCartItem(buyerId);
	for(CartItem items:cartItem) {
		Optional<OrderItem> item = itemRepository.findById(items.getItemId());
	Amount +=item.get().getPrice()*items.getQuantity();
	}
Optional<BuyerInfo> buyer=buyerRepository.findById(buyerId);
transactionHistory=new TransactionHistory();
transactionHistory.setTransactionAmount(Amount);

transactionHistory.setBuyer(buyer.get());
transactionHistory.setRemarks("payment done");
transactionHistoryRepository.save(transactionHistory);
for(CartItem items:cartItem) {
	purchaseHistory=new PurchaseHistory();
	purchaseHistory.setBuyer(buyer.get());
	purchaseHistory.setTransaction(transactionHistory);
	purchaseHistory.setItemId(items.getItemId());
	purchaseHistory.setRemarks("Done");
	purchaseHistory.setNumberOfItems(items.getQuantity());
	Optional<OrderItem> item = itemRepository.findById(items.getItemId());
	Integer currentStock = item.get().getStock();
	item.get().setStock(currentStock - items.getQuantity());
	purchaseHistoryRepository.save(purchaseHistory);
}
	cartRepository.deleteByBuyerId(buyerId);
}

}
