package com.egg.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.egg.model.CartItem;
import com.egg.service.impl.CartService;


@CrossOrigin(origins = "*")
@RestController
public class CartControllerClass {

@Autowired
private CartService cartService;

@RequestMapping(value="{buyerId}/addToCart", method=RequestMethod.POST ,produces="application/json")
public CartItem addToCart(@PathVariable (value="buyerId") Integer buyerId,@RequestBody CartItem cartItem ) {
     	CartItem newItem = cartService.addToCartItem(cartItem,buyerId);
     	return newItem;
}
@RequestMapping(value="/{buyerId}/getAllCartItems",method=RequestMethod.GET,produces="application/json")
public List<CartItem> getAllItems(@PathVariable (value="buyerId") Integer buyerId){
	 List<CartItem> items=cartService.getAllCartItems(buyerId);
	 return items;
}

@RequestMapping(value="/{cartItemId}/deleteItemById",method=RequestMethod.DELETE)
public String deleteItemById(@PathVariable (value ="cartItemId") Integer cartItemId) {
	 String state= cartService.deleteCartItem(cartItemId);
	 return state;
}

@RequestMapping(value="/{buyerId}/deleteAllItem",method=RequestMethod.DELETE)
public String deleteAllItem(@PathVariable (value="buyerId") Integer buyerId) {
	return cartService.deleteAllCartItem(buyerId);
}
@RequestMapping(value="/{cartItemId}/updateCartItem",method=RequestMethod.PUT,produces="application/json")
public CartItem updateCartItem(@PathVariable (value="cartItemId") Integer cartItemId,@RequestBody CartItem cartItem) {
  return cartService.updateCartItems(cartItem,cartItemId);
}
@RequestMapping(value="/{buyerId}/checkout",method=RequestMethod.POST,produces="application/json")
public String checkout(@PathVariable(value="buyerId") Integer buyerId) {
	cartService.checkOut(buyerId);
	return "checkout";
}
}
