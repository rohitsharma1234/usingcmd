package com.egg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.egg.model.BuyerInfo;
import com.egg.service.impl.BuyerService;


@CrossOrigin(origins = "*")
@RestController
public class BuyerControllerClass {

	@Autowired
	private BuyerService buyerService;
	
	@RequestMapping (value="adduser", method=RequestMethod.POST, produces="application/json")
	public BuyerInfo addProduct(@RequestBody BuyerInfo buyer) {
	BuyerInfo buyerinfo = buyerService.addBuyer(buyer);
	return buyerinfo;
	}	
}
