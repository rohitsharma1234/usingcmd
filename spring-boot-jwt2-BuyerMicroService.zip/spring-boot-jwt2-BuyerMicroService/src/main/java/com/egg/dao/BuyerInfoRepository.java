package com.egg.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.egg.model.BuyerInfo;

//import com.demo.buyerentityclass.BuyerInfo;

@Repository
public interface BuyerInfoRepository extends JpaRepository<BuyerInfo,Integer>{

	BuyerInfo findByUsername(String username);



	
	
	
}
