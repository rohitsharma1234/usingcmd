package com.egg.dao;


import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.egg.model.CartItem;





@Repository
public interface CartRepository extends JpaRepository<CartItem,Integer> {
@Transactional
@Modifying
@Query(value="DELETE FROM cart_item WHERE buyer_id = :buyerId ", nativeQuery =true)
public void deleteByBuyerId(@Param ("buyerId") Integer buyerId);
@Query(value="SELECT * FROM cart_item WHERE buyer_id = :buyerId",nativeQuery=true)
public List<CartItem> findAllCartItem(@Param ("buyerId") Integer buyerId);

}
