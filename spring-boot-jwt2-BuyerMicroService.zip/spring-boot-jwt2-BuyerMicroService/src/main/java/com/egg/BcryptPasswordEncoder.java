package com.egg;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class BcryptPasswordEncoder {
	

		public static void main(String[] args) {

			
			 
				BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
			

		  }
	}

