package com.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.entity.SellerInfo;
import com.demo.repositories.ItemsRepo;
import com.demo.repositories.SellerRepo;
import com.demo.services.ItemsService;
import com.demo.services.SellerService;
@CrossOrigin("*")
@RestController
@RequestMapping("/addSeller")
public class SelleController {
@Autowired
private ItemsService itemService;
@Autowired 
private SellerService sellerService;
  
@PostMapping(name="/addSeller", produces="application/json")
public SellerInfo addSeller(@RequestBody SellerInfo seller) {
	System.out.println("jdsfjakl");
	return sellerService.addSeller(seller);
	
}



}
