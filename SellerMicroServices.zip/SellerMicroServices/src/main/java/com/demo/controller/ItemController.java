package com.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.demo.entity.Items;
import com.demo.services.ItemsService;
import com.demo.services.SellerService;
@CrossOrigin("*")
@RestController
public class ItemController {

	
	@Autowired
	private ItemsService itemService;
	@Autowired
	private SellerService sellerService;
	
	@RequestMapping(value="/{sellerId}/additems")
	public Items addItem(@RequestBody Items item,@PathVariable("sellerId") Integer sellerId) {
		return itemService.addItems(item, sellerId);
	}
	
	@RequestMapping("/getallItem")
	public List<Items> getAllItem() {
		return itemService.getAllItem();
	}
	@RequestMapping("/{sellerId}/{itemId}/deleteItem")
	public void deleteItemById(@PathVariable("sellerId") Integer sellerId,@PathVariable ("itemId") Integer itemId) {
		System.out.println("lkrgj");
		 itemService.deleteItemById(sellerId,itemId);
		 System.out.println("deleted");
	}
	@RequestMapping("/updateItem/{itemId}")
	public Items  updateAllItemById(@RequestBody Items item,@PathVariable("itemId")Integer itemId){
		return itemService.updateItem(item,itemId);
	}
	@RequestMapping(value="/searchItem/{itemName}",method=RequestMethod.GET)
	public List<Items> searchItemByName(@PathVariable(value="itemName") String name) {
		System.out.println(name);
		return itemService.searchItem(name);
		
	}
}
