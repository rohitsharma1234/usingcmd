package com.demo.repositories;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.demo.entity.Items;

public interface ItemsRepo extends JpaRepository <Items,Integer>{


	@Transactional
	@Modifying
	@Query(value = "DELETE FROM items WHERE items.seller_id = :sellerId and items.item_id = :itemId", nativeQuery = true)
	public void deleteItemById(@Param("sellerId") Integer sellerId, @Param("itemId") Integer itemId);
	
	@Query(value="From Items where itemName like %:name%")
	public List<Items> findByName(@Param ("name") String name);
}
