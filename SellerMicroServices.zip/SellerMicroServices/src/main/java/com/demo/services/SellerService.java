package com.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.entity.SellerInfo;
import com.demo.repositories.SellerRepo;

@Service
public class SellerService {

	@Autowired
   private SellerRepo sellerRepo;
	
	public SellerInfo addSeller(SellerInfo sellerInfo) {
		return sellerRepo.save(sellerInfo);
	}
}
