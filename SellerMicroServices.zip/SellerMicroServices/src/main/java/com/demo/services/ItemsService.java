package com.demo.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.entity.Items;
import com.demo.entity.SellerInfo;
import com.demo.repositories.ItemsRepo;
import com.demo.repositories.SellerRepo;

@Service
public class ItemsService {

	@Autowired
	private ItemsRepo itemRepo;
	@Autowired
	private SellerRepo sellerRepo;
	
	public Items addItems(Items items,Integer sellerId) {
		Optional<SellerInfo> seller  =sellerRepo.findById(sellerId);
		items.setSeller(seller.get());
		return itemRepo.save(items);
		
	}
	
	public List<Items> getAllItem(){
		return itemRepo.findAll();
	}
	
	public void  deleteItemById(Integer sellerId,Integer itemId) {
		 itemRepo.deleteItemById(sellerId,itemId);
	}
	public Items updateItem(Items item,Integer itemId) {
		Optional <Items>  Item = itemRepo.findById(itemId);
		if(Item.isPresent()) {
			Items updatedItem=Item.get();
			updatedItem.setStock(item.getStock());
			updatedItem.setCategoryId(item.getCategoryId());
			updatedItem.setDescription(item.getDescription());
			updatedItem.setItemName(item.getItemName());
			updatedItem.setRemarks(item.getRemarks());
			updatedItem.setSeller(item.getSeller());
			updatedItem.setStock(item.getStock());
			updatedItem.setSubCategoryId(item.getSubCategoryId());
			return itemRepo.save(updatedItem);
		}
		return null;
	}
	
	public List<Items> searchItem(String name){
	List<Items>	 item= itemRepo.findByName(name);
	System.out.println("items are here"+item);
	return item;
	
	}

	
	
	
}
