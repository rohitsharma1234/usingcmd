package com.demo.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class CategoryClass implements Serializable{
	@Id
	@GeneratedValue
	private Integer categoryId;
	private String categoryName;
	private String briefDetail;
	public CategoryClass() {
		
	}
	public CategoryClass(Integer categoryId, String categoryName, String briefDetail) {
		super();
		this.categoryId = categoryId;
		this.categoryName = categoryName;
		this.briefDetail = briefDetail;
	}
	public Integer getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(Integer categoryId) {
		this.categoryId = categoryId;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public String getBriefDetail() {
		return briefDetail;
	}
	public void setBriefDetail(String briefDetail) {
		this.briefDetail = briefDetail;
	}
	@Override
	public String toString() {
		return "CategoryClass [categoryId=" + categoryId + ", categoryName=" + categoryName + ", briefDetail="
				+ briefDetail + "]";
	}
	
}
