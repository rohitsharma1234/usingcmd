package com.demo.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class SellerInfo implements Serializable {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer sellerId;
	private String username;
	private String password;
	private String companyName;
	private String gstin;
	private String briefAboutCompany;
	private String postalAddress;
	private String website;
	private String email;
	private Long contactNumber;
	public SellerInfo() {
		
	}
	public Integer getSellerId() {
		return sellerId;
	}
	public void setSellerId(Integer sellerId) {
		this.sellerId = sellerId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getGstin() {
		return gstin;
	}
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}
	public String getBriefAboutCompany() {
		return briefAboutCompany;
	}
	public void setBriefAboutCompany(String briefAboutCompany) {
		this.briefAboutCompany = briefAboutCompany;
	}
	public String getPostalAddress() {
		return postalAddress;
	}
	public void setPostalAddress(String postalAddress) {
		this.postalAddress = postalAddress;
	}
	public String getWebsite() {
		return website;
	}
	public void setWebsite(String website) {
		this.website = website;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Long getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(Long contactNumber) {
		this.contactNumber = contactNumber;
	}
	public SellerInfo(Integer sellerId, String username, String password, String companyName, String gstin,
			String briefAboutCompany, String postalAddress, String website, String email, Long contactNumber) {
		super();
		this.sellerId = sellerId;
		this.username = username;
		this.password = password;
		this.companyName = companyName;
		this.gstin = gstin;
		this.briefAboutCompany = briefAboutCompany;
		this.postalAddress = postalAddress;
		this.website = website;
		this.email = email;
		this.contactNumber = contactNumber;
	}
	@Override
	public String toString() {
		return "SellerInfo [sellerId=" + sellerId + ", username=" + username + ", password=" + password
				+ ", companyName=" + companyName + ", gstin=" + gstin + ", briefAboutCompany=" + briefAboutCompany
				+ ", postalAddress=" + postalAddress + ", website=" + website + ", email=" + email + ", contactNumber="
				+ contactNumber + "]";
	}
	
}
