package Hibernate2;
@Entity
public class OrderItem {
	@Id
	@ManytoOne
private int  Order_Item_Id;
private String ProductName;

}
