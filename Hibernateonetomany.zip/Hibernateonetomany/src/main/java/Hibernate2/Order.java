package Hibernate2;
import javax.persistence.Entity;
@Entity
public class Order {
	public Order() {
	}
	
@Id
private int order_id;
private String Description;
public int getOrder_id() {
	return order_id;
}
public void setOrder_id(int order_id) {
	this.order_id = order_id;
}
public String getDescription() {
	return Description;
}
public void setDescription(String description) {
	Description = description;
}
public Order(int order_id, String description) {
	super();
	this.order_id = order_id;
	Description = description;
}


}
