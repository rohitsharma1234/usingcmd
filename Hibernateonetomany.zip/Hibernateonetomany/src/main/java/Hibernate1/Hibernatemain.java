package Hibernate1;

import java.lang.module.Configuration;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.cts.hibernate.model.Account;
import com.cts.hibernate.model.DematAccount;
import com.cts.hibernate.model.SavingsAccount;

import Hibernate2.Order;
import Hibernate2.OrderItem;

public class Hibernatemain {

	public static void main(String[] args) {
		Configuration configuration=new Configuration().Configure();
		SessionFactory sf=configuration.buildSessionFactory();
		Session session=sf.openSession();
		Order od=new Order();
		od.setDescription("my product is fine");
		OrderItem ot=new OrderItem();
		ot.setProductName("food");
		session.beginTransaction();
		session.save(od);
		session.save(ot);
		session.getTransaction().commit();
		
		

	}

}
