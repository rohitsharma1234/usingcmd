package com.cts.springbootdao;
import org.springframework.stereotype.Repository;

import com.cts.springboot.Person;
import java.util.List;
@Repository
public interface IPersonDao extends JpaRepository<Person, Integer> {

	
	
	@Query(value="From Person p where p.PersonId=p:pi")
	public Person findByPersonId(@Param("pi") int id);
	@Query(value="From Person p where p.PersonName=p:pn")
	public Person findByPersonName(@Param("pn") String Name );
	@Query(value="From Person p where p.PersonId=p:addr")
	public Person findByPersonAddr(@Param("pd") String addr);
}
