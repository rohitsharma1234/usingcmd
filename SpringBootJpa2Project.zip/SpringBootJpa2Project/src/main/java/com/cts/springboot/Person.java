package com.cts.springboot;

public class Person {

	private int Id;
	private String Name;
	private String Addr;
	  
	
	public void Person() {
		
	}


	public int getId() {
		return Id;
	}


	public void setId(int id) {
		Id = id;
	}


	public String getName() {
		return Name;
	}


	public void setName(String name) {
		Name = name;
	}


	public String getAddr() {
		return Addr;
	}


	public void setAddr(String addr) {
		Addr = addr;
	}


	public Person(int id, String name, String addr) {
		super();
		Id = id;
		Name = name;
		Addr = addr;
	}


	@Override
	public String toString() {
		return "Person [Id=" + Id + ", Name=" + Name + ", Addr=" + Addr + "]";
	}
	
}
