package com.cts.springboot;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;

import springbootservice.IPersonService;


@RestController
public class MyController {

	@Autowired
	private IPersonService service;
	@RequestMapping("getById/{eid}")
	public Person getById(@PathVariable("eid") int Id) {
		return service.getPersonById(Id);
	}
	@RequestMapping("getByName/{ename}")
	public Person getByName(@PathVariable("ename") String Name) {
		return service.getPersonByName(Name);
	}
	@RequestMapping("getByAddr/{eaddr")
	public Person getByAddr(@PathVariable("eaddr") String Addr) {
		return service.getPersonByAddr(Addr);
	}
}
