package com.cts.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class SpringBootData {
public static void main(String s[]) {
	SpringApplication.run(SpringBootData.class, s);
}
}
