package springbootservice;

import com.cts.springboot.Person;
import com.cts.springbootdao.IPersonDao;

public class PersonService {

	
	private IPersonDao idao;
	public Person getPersonById(int Id) {
		return idao.findByPersonId(Id);
	}
	public Person getPersonByName(String Name) {
		return idao.findByPersonName(Name);
	}
	public Person getPersonByAddr(String Addr) {
		return idao.findByPersonAddr(Addr);
	}
}
