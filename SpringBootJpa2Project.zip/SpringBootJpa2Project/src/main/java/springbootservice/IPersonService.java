package springbootservice;

import com.cts.springboot.Person;

public interface IPersonService {
  
	
	public Person getPersonById(int Id);
	public Person getPersonByName(String Name);
	public Person getPersonByAddr(String Addr);

}
