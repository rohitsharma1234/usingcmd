package com.cts.details;
import java.io.Serializable;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table
public class Category implements Serializable{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int category_id;
	 @Column(name = "Category_name")
	private String category_name;
	private String brief_details;
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "CATEGORY_ID")
	private List<Subcategory> subcategory;
		
	
	public int getCategory_id() {
		return category_id;
	}
	public void setCategory_id(int category_id) {
		this.category_id = category_id;
	}
	public String getCategory_name() {
		return category_name;
	}
	public void setCategory_name(String category_name) {
		this.category_name = category_name;
	}
	@Override
	public String toString() {
		return "Category [category_id=" + category_id + ", category_name=" + category_name + ", brief_details="
				+ brief_details + "]";
	}
	public String getBrief_details() {
		return brief_details;
	}
	public void setBrief_details(String brief_details) {
		this.brief_details = brief_details;
	}

}
