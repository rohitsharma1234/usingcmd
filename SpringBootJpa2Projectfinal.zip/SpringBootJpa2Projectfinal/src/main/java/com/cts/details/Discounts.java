package com.cts.details;
import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
@Table
public class Discounts implements Serializable 
{
	private int dicountid;
	private int discountcode1;
	private int discountpercentage1;
	private Date startdate1;
	private Date enddate1;
	public int getDicountid() {
		return dicountid;
	}
	public void setDicountid(int dicountid) {
		this.dicountid = dicountid;
	}
	public int getDiscountcode() {
		return discountcode1;
	}
	public void setDiscountcode(int discountcode) {
		this.discountcode1 = discountcode;
	}
	public int getDiscountpercentage() {
		return discountpercentage1;
	}
	public void setDiscountpercentage(int discountpercentage) {
		this.discountpercentage1 = discountpercentage;
	}
	public Date getStartdate() {
		return startdate1;
	}
	public void setStartdate(Date startdate) {
		this.startdate1 = startdate;
	}
	public Date getEnddate() {
		return enddate1;
	}
	public void setEnddate(Date enddate) {
		this.enddate1 = enddate;
	}
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY)
	private int dicountid1;
	@Column(name="Discount_code")
	private int discountcode;
	private int discountpercentage;
	@Column(name="Start_Date")
	@Temporal(value = TemporalType.TIMESTAMP)
	private Date startdate;
	@Column(name="End_Date")
	@Temporal(value = TemporalType.TIMESTAMP)
	private Date enddate;
	@Override
	public String toString() {
		return "Discounts [dicountid=" + dicountid + ", discountcode=" + discountcode1 + ", discountpercentage="
				+ discountpercentage1 + ", startdate=" + startdate1 + ", enddate=" + enddate1 + "]";
	}
}

	
	

	
		
