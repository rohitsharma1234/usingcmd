package com.cts.details;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
@Entity
@Table(name="Subcategory")
public class Subcategory implements Serializable {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
private int subcategory_id;
private String subcategory_name;

private String breif_details;
private int gst_details;

public Subcategory() {
	
}


public int getSubcategory_id() {
	return subcategory_id;
}
public void setSubcategory_id(int subcategory_id) {
	this.subcategory_id = subcategory_id;
}
public String getSubcategory_name() {
	return subcategory_name;
}
public void setSubcategory_name(String subcategory_name) {
	this.subcategory_name = subcategory_name;
}

public String getBreif_details() {
	return breif_details;
}
public void setBreif_details(String breif_details) {
	this.breif_details = breif_details;
}
public int getGst_details() {
	return gst_details;
}
public void setGst_details(int gst_details) {
	this.gst_details = gst_details;
}
public Subcategory(int subcategory_id, String subcategory_name,  String breif_details,
		int gst_details) {
	super();
	this.subcategory_id = subcategory_id;
	this.subcategory_name = subcategory_name;
	
	this.breif_details = breif_details;
	this.gst_details = gst_details;
}
@Override
public String toString() {
	return "Subcategory [subcategory_id=" + subcategory_id + ", subcategory_name=" + subcategory_name + ", breif_details=" + breif_details + ", gst_details=" + gst_details + "]";
}



}
