package com.cts.details;
import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
@Table (name ="Buyer")
public class Buyer implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int Buyerid;
	@Column(name = "user_name")
	private String username1;
    private String password1;
	private String email1;
	private int mobile_no1;
    @Temporal(value= TemporalType.TIMESTAMP)
	private Date createddatetime;
    
    public Buyer() {
    	
    }
	public Buyer(int buyerid, String username1, String password1, String email1, int mobile_no1, Date createddatetime) {
		super();
		Buyerid = buyerid;
		this.username1 = username1;
		this.password1 = password1;
		this.email1 = email1;
		this.mobile_no1 = mobile_no1;
		this.createddatetime = createddatetime;
	}
	public int getBuyerid() {
		return Buyerid;
	}
	public void setBuyerid(int buyerid) {
		Buyerid = buyerid;
	}
	public String getUsername1() {
		return username1;
	}
	public void setUsername1(String username1) {
		this.username1 = username1;
	}
	public String getPassword1() {
		return password1;
	}
	public void setPassword1(String password1) {
		this.password1 = password1;
	}
	public String getEmail1() {
		return email1;
	}
	public void setEmail1(String email1) {
		this.email1 = email1;
	}
	public int getMobile_no1() {
		return mobile_no1;
	}
	public void setMobile_no1(int mobile_no1) {
		this.mobile_no1 = mobile_no1;
	}
	public Date getCreateddatetime() {
		return createddatetime;
	}
	public void setCreateddatetime(Date createddatetime) {
		this.createddatetime = createddatetime;
	}
	@Override
	public String toString() {
		return "Buyer [Buyerid=" + Buyerid + ", username1=" + username1 + ", password1=" + password1 + ", email1="
				+ email1 + ", mobile_no1=" + mobile_no1 + ", createddatetime=" + createddatetime + "]";
	}

	
	
}
	