package com.cts.details;

import java.io.Serializable ;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="Purchasehistorty")
public class Purchasehistory implements Serializable 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
  private int purchaseid;
	@Column(name="Buyer_id")
	private int buyerid;
	private int sellerid;
	private int transcationid;
	private int itemid;
	@Column(name="number_of_items")
	private int noofitems;
	@Temporal(value = TemporalType.TIMESTAMP)
	private Date datetime;
	private String remarks;
	public int getPurchaseid() {
		return purchaseid;
	}

	public int getBuyerid() {
		return buyerid;
	}
	public void setBuyerid(int buyerid) {
		this.buyerid = buyerid;
	}
	public int getSellerid() {
		return sellerid;
	}
	public void setSellerid(int sellerid) {
		this.sellerid = sellerid;
	}
	public int getTranscationid() {
		return transcationid;
	}
	public void setTranscationid(int transcationid) {
		this.transcationid = transcationid;
	}
	public int getItemid() {
		return itemid;
	}
	public void setItemid(int itemid) {
		this.itemid = itemid;
	}
	public int getNoofitems() {
		return noofitems;
	}
	public void setNoofitems(int noofitems) {
		this.noofitems = noofitems;
	}
	public Date getDatetime() {
		return datetime;
	}
	public void setDatetime(Date datetime) {
		this.datetime = datetime;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public void setPurchaseid(int purchaseid) {
		this.purchaseid = purchaseid;
		
		
	}
	public Purchasehistory(int purchaseid, int buyerid, int sellerid, int transcationid, int itemid, int noofitems,
			Date datetime, String remarks) {
		super();
		this.purchaseid = purchaseid;
		this.buyerid = buyerid;
		this.sellerid = sellerid;
		this.transcationid = transcationid;
		this.itemid = itemid;
		this.noofitems = noofitems;
		this.datetime = datetime;
		this.remarks = remarks;
	}
	@Override
	public String toString() {
		return "Purchasehistory [purchaseid=" + purchaseid + ", buyerid=" + buyerid + ", sellerid=" + sellerid
				+ ", transcationid=" + transcationid + ", itemid=" + itemid + ", noofitems=" + noofitems + ", datetime="
				+ datetime + ", remarks=" + remarks + "]";
	}
}