package com.example.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface BuyerInfoRepository extends JpaRepository<BuyerInfo,Integer>{

	
	
}
