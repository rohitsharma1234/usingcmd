package com.emart.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.emart.entity.Items;

@Repository
public interface IItem extends JpaRepository<Items, Integer>{
	@Query(value = "SELECT * FROM item_seller WHERE item_seller.seller_id = :sellerId", nativeQuery = true)
	public List<Items> findBySellerId(@Param("sellerId")Integer sellerId); 
	
	@Query(value = "SELECT * FROM item_seller WHERE item_seller.seller_id = :sellerId and item_seller.item_id = :itemId", nativeQuery = true)
	public void deleteItemById(@Param("sellerId") Integer sellerId, @Param("itemId") Integer itemId);
}
