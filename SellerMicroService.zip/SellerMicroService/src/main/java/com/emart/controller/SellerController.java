package com.emart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.emart.entity.Items;
import com.emart.entity.Seller;
import com.emart.services.ItemService;
import com.emart.services.SellerService;

@RestController
@RequestMapping("/seller")
public class SellerController {
	
	@Autowired
	private SellerService sellerService;
	
	@Autowired
	private ItemService itemService;
	
	@PostMapping(name = "/seller", produces = "application/json")
	public Seller addSeller(@RequestBody Seller seller) {
		
		return sellerService.addSeller(seller); 
	}
	
	@PostMapping(name = "/{sellerId}/additems")
	public Items addItems(@RequestBody Items item, @PathVariable("sellerId") Integer sellerId) {
		
		return itemService.addItems(item, sellerId);  
	}
}
