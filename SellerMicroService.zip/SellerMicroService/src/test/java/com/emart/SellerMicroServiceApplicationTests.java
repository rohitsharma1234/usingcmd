package com.emart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SellerMicroServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
